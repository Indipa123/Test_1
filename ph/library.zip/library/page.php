<!DOCTYPE html>
<html>
<head>
    <title>Simple Library Management System</title>
    <style>
        .section {
            width: 55%;
            height: 50%;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            background-color: rgba(193, 90, 22, 0.63);
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .form-container {
            margin-top: 40px;
            width: 50%;
        }

        .form-container label, .form-container input {
            display: inline-block;
            margin-bottom: 10px;
        }  

        .form-container input[type="text"] {
            width: 55%;
        }

        .info-container {
            width: 80%;
            text-align: right;
            margin-right: 30px;
        }

        .info-container h2 {
            margin-top: 10px;
        }

        .info-container h2, .info-container a {
            margin-bottom: 250px;
        }

        .info-container a {
            text-align: center;
            margin-bottom: 20px;
        }

        .success-message {
            color: green;
            font-weight: bold;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="section">
        <div class="form-container">
            <form method="post" action="">
                <label for="isbn">Enter ISBN:</label>
                <input type="text" id="isbn" name="isbn"><br>
                <label for="title">Enter Title:</label>
                <input type="text" id="title" name="title"><br>
                <label for="author">Enter Author:</label>
                <input type="text" id="author" name="author"><br>
                <label for="edition">Enter Edition:</label>
                <input type="text" id="edition" name="edition"><br>
                <label for="publication">Enter Publication:</label>
                <input type="text" id="publication" name="publication"><br>
                <input type="submit" name="submit" value="Submit">
                <input type="reset" value="Reset">
            </form>
        </div>

        <div class="info-container">
            <h2>Simple Library Management System</h2>
            
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Collect form data
                $isbn = $_POST['isbn'];
                $title = $_POST['title'];
                $author = $_POST['author'];
                $edition = $_POST['edition'];
                $publication = $_POST['publication'];

                // Include the database connection file
                include 'DbConnection.php';

                // Insert data into the book_info table
                $sql = "INSERT INTO book_info (isbn, title, author, edition, publication) VALUES ('$isbn', '$title', '$author', '$edition', '$publication')";

                if ($conn->query($sql) === TRUE) {
                    echo "<p class='success-message'>New record created successfully</p>";
                } else {
                    echo "<p class='success-message'>Error: " . $sql . "<br>" . $conn->error . "</p>";
                }

                $conn->close();
            }
            ?>
            <a href="search_book.php">To search for the Book information click here</a>
        </div>
    </div>
</body>
</html>
