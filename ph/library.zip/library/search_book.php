<!DOCTYPE html>
<html>
<head>
    <title>Search Book</title>
    <style>
        .search-container {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }
        .search-container input[type="text"] {
            width: 70%;
            padding: 10px;
            margin-right: 10px;
        }
        .search-container input[type="submit"] {
            padding: 10px 20px;
        }
        .result-container {
            width: 50%;
            margin: 20px auto;
            text-align: left;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
    </style>
</head>
<body>
    <div class="search-container">
        <h2>Search for a Book</h2>
        <form method="post" action="">
            <input type="text" name="search" placeholder="Enter book title">
            <input type="submit" name="submit" value="Search">
        </form>
    </div>
    <div class="result-container">
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $search = $_POST['search'];

            // Include the database connection file
            include 'DbConnection.php';

            // Search for books by title
            $sql = "SELECT * FROM book_info WHERE title LIKE '%$search%'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<table>";
                echo "<tr><th>ISBN</th><th>Title</th><th>Author</th><th>Edition</th><th>Publication</th></tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["isbn"]. "</td><td>" . $row["title"]. "</td><td>" . $row["author"]. "</td><td>" . $row["edition"]. "</td><td>" . $row["publication"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No results found</p>";
            }

            $conn->close();
        }
        ?>
    </div>
</body>
</html>
